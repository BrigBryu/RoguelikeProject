#ifndef FILE_HANDLE_H
#define FILE_HANDLE_H

#include "dungeon.h"

void writeDungeon(Dungeon *dungeon);
void readDungeon(Dungeon *dungeon, char *testDungeon);

#endif
