#ifndef SIMULATE_H
#define SIMULATE_H

#include "dungeon.h"

int simulateMonsters(Dungeon *dungeon);

#endif