#ifndef FILE_HANDLE_HPP
#define FILE_HANDLE_HPP

#include "dungeon.hpp"

void writeDungeon(Dungeon *dungeon);
void readDungeon(Dungeon *dungeon, char *testDungeon);

#endif
