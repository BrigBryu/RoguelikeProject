#ifndef SIMULATE_HPP
#define SIMULATE_HPP

#include "dungeon.hpp"

int simulateMonsters(Dungeon *dungeon);

#endif