#ifndef GLOBALVARIABLES_HPP
#define GLOBALVARIABLES_HPP

#include "monsterParser.hpp"

// Global monster list to be accessible throughout the program
extern MonsterList* globalMonsterList;

#endif 